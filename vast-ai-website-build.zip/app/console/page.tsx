import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { ConsoleDashboard } from "@/components/console-dashboard"
import type { Instance, Profile } from "@/lib/types"

export default async function ConsolePage() {
  const supabase = await createClient()

  const {
    data: { user },
    error,
  } = await supabase.auth.getUser()

  if (error || !user) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  const { data: instances } = await supabase
    .from("instances")
    .select("*, gpu_machines(*)")
    .eq("user_id", user.id)
    .neq("status", "destroyed")
    .order("created_at", { ascending: false })

  return (
    <ConsoleDashboard
      profile={profile as Profile}
      instances={(instances as (Instance & { gpu_machines: any })[]) || []}
    />
  )
}
