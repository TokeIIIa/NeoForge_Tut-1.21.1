import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { APIKeysPage } from "@/components/api-keys-page"
import type { Profile, SSHKey } from "@/lib/types"

export default async function KeysRoute() {
  const supabase = await createClient()

  const {
    data: { user },
    error,
  } = await supabase.auth.getUser()

  if (error || !user) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  const { data: sshKeys } = await supabase
    .from("ssh_keys")
    .select("*")
    .eq("user_id", user.id)
    .order("created_at", { ascending: false })

  return <APIKeysPage profile={profile as Profile} sshKeys={(sshKeys as SSHKey[]) || []} />
}
