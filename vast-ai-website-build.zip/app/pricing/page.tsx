import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Check, Zap, Server, Shield } from "lucide-react"

const pricingTiers = [
  {
    name: "On-Demand",
    description: "Fixed pricing, guaranteed resources",
    features: ["No interruptions", "Instant availability", "Full resource access", "Priority support"],
    cta: "Browse GPUs",
    href: "/search",
  },
  {
    name: "Interruptible",
    description: "Up to 50% cheaper, may be paused",
    features: ["Lowest prices available", "Great for batch jobs", "Flexible scheduling", "Auto-restart available"],
    cta: "Find Deals",
    href: "/search?interruptible=true",
    highlight: true,
  },
  {
    name: "Reserved",
    description: "Long-term commitment discounts",
    features: ["Up to 50% off on-demand", "Guaranteed capacity", "Weekly/monthly terms", "Best for production"],
    cta: "Contact Sales",
    href: "/contact",
  },
]

const gpuPricing = [
  { name: "H100 80GB", onDemand: "$2.95", interruptible: "$2.35", description: "Latest data center GPU" },
  { name: "A100 80GB", onDemand: "$1.85", interruptible: "$1.45", description: "Enterprise AI training" },
  { name: "A100 40GB", onDemand: "$1.25", interruptible: "$0.95", description: "ML workloads" },
  { name: "RTX 4090", onDemand: "$0.45", interruptible: "$0.35", description: "Consumer flagship" },
  { name: "RTX 3090", onDemand: "$0.25", interruptible: "$0.18", description: "High performance" },
  { name: "RTX 3080", onDemand: "$0.15", interruptible: "$0.10", description: "Great value" },
  { name: "RTX 3070", onDemand: "$0.08", interruptible: "$0.05", description: "Budget option" },
]

export default function PricingPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-1">
        {/* Hero */}
        <section className="py-16 md:py-24">
          <div className="container px-4">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h1 className="text-4xl md:text-5xl font-bold mb-4">Simple, Transparent Pricing</h1>
              <p className="text-xl text-muted-foreground">
                Pay only for what you use. No hidden fees, no commitments. Prices vary by supply and demand.
              </p>
            </div>

            {/* Pricing Tiers */}
            <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto mb-24">
              {pricingTiers.map((tier) => (
                <Card key={tier.name} className={tier.highlight ? "border-primary shadow-lg shadow-primary/10" : ""}>
                  <CardHeader>
                    <CardTitle>{tier.name}</CardTitle>
                    <p className="text-sm text-muted-foreground">{tier.description}</p>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-3 mb-6">
                      {tier.features.map((feature) => (
                        <li key={feature} className="flex items-center gap-2 text-sm">
                          <Check className="h-4 w-4 text-primary" />
                          {feature}
                        </li>
                      ))}
                    </ul>
                    <Button className="w-full" variant={tier.highlight ? "default" : "outline"} asChild>
                      <Link href={tier.href}>{tier.cta}</Link>
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* GPU Pricing Table */}
            <div className="max-w-4xl mx-auto">
              <h2 className="text-2xl font-bold text-center mb-8">Sample GPU Pricing</h2>
              <Card>
                <CardContent className="p-0">
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-border">
                          <th className="text-left p-4 font-medium">GPU Model</th>
                          <th className="text-left p-4 font-medium">On-Demand</th>
                          <th className="text-left p-4 font-medium">Interruptible</th>
                          <th className="text-left p-4 font-medium hidden md:table-cell">Use Case</th>
                        </tr>
                      </thead>
                      <tbody>
                        {gpuPricing.map((gpu) => (
                          <tr key={gpu.name} className="border-b border-border/50 last:border-0">
                            <td className="p-4">
                              <div className="flex items-center gap-2">
                                <Zap className="h-4 w-4 text-primary" />
                                <span className="font-medium">{gpu.name}</span>
                              </div>
                            </td>
                            <td className="p-4 font-mono">{gpu.onDemand}/hr</td>
                            <td className="p-4 font-mono text-primary">{gpu.interruptible}/hr</td>
                            <td className="p-4 text-muted-foreground hidden md:table-cell">{gpu.description}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
              <p className="text-center text-sm text-muted-foreground mt-4">
                * Prices shown are starting prices and may vary based on availability
              </p>
            </div>
          </div>
        </section>

        {/* Additional Info */}
        <section className="py-16 bg-card/30 border-y border-border/40">
          <div className="container px-4">
            <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
              <div className="text-center">
                <div className="mx-auto w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                  <Server className="h-6 w-6 text-primary" />
                </div>
                <h3 className="font-semibold mb-2">Billed Per Second</h3>
                <p className="text-sm text-muted-foreground">
                  Pay only for the exact time you use. Stop instances anytime.
                </p>
              </div>
              <div className="text-center">
                <div className="mx-auto w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                  <Shield className="h-6 w-6 text-primary" />
                </div>
                <h3 className="font-semibold mb-2">No Hidden Fees</h3>
                <p className="text-sm text-muted-foreground">
                  Storage and bandwidth included. What you see is what you pay.
                </p>
              </div>
              <div className="text-center">
                <div className="mx-auto w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                  <Zap className="h-6 w-6 text-primary" />
                </div>
                <h3 className="font-semibold mb-2">Dynamic Pricing</h3>
                <p className="text-sm text-muted-foreground">
                  Prices adjust based on supply and demand for best deals.
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
