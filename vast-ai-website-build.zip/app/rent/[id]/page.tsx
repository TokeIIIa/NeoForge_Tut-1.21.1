import { createClient } from "@/lib/supabase/server"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { RentForm } from "@/components/rent-form"
import { notFound } from "next/navigation"
import type { GPUMachine, Template } from "@/lib/types"

export default async function RentPage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = await params
  const supabase = await createClient()

  const { data: machine } = await supabase.from("gpu_machines").select("*").eq("id", id).single()

  if (!machine) {
    notFound()
  }

  const { data: templates } = await supabase.from("templates").select("*").eq("is_public", true).order("name")

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-1 container px-4 py-8">
        <RentForm machine={machine as GPUMachine} templates={(templates as Template[]) || []} />
      </main>
      <Footer />
    </div>
  )
}
