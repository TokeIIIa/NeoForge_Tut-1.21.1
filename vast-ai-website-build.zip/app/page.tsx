import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Zap, DollarSign, Globe, Shield, ArrowRight, Check, Sparkles, Server, Cpu, Cloud, Lock } from "lucide-react"

const gpuStats = [
  { label: "Available GPUs", value: "50,000+", color: "text-primary" },
  { label: "Data Centers", value: "150+", color: "text-accent" },
  { label: "Countries", value: "40+", color: "text-primary" },
  { label: "Avg. Savings", value: "80%", color: "text-accent" },
]

const features = [
  {
    icon: DollarSign,
    title: "Lowest Prices",
    description:
      "Access GPUs at up to 80% lower cost than traditional cloud providers through our competitive marketplace.",
    gradient: "from-primary/20 to-amber-500/10",
  },
  {
    icon: Zap,
    title: "Instant Deploy",
    description: "Launch GPU instances in seconds with pre-configured templates for PyTorch, TensorFlow, and more.",
    gradient: "from-accent/20 to-cyan-400/10",
  },
  {
    icon: Globe,
    title: "Global Network",
    description: "Choose from thousands of GPUs across 150+ data centers worldwide for optimal performance.",
    gradient: "from-primary/20 to-amber-500/10",
  },
  {
    icon: Shield,
    title: "Secure & Reliable",
    description: "Enterprise-grade security with encrypted connections and verified host machines.",
    gradient: "from-accent/20 to-cyan-400/10",
  },
]

const gpuTypes = [
  {
    name: "H100 80GB",
    price: "$2.35",
    unit: "/hr",
    performance: "3850 TFLOPS",
    tag: "Latest",
    tagColor: "bg-primary/20 text-primary",
  },
  {
    name: "A100 80GB",
    price: "$1.45",
    unit: "/hr",
    performance: "312 TFLOPS",
    tag: "Popular",
    tagColor: "bg-accent/20 text-accent",
  },
  { name: "RTX 4090", price: "$0.35", unit: "/hr", performance: "95 TFLOPS", tag: null, tagColor: "" },
  {
    name: "RTX 3090",
    price: "$0.18",
    unit: "/hr",
    performance: "68 TFLOPS",
    tag: "Budget",
    tagColor: "bg-secondary text-muted-foreground",
  },
]

export default function HomePage() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />

      <main className="flex-1">
        {/* Hero Section - Kilo Code inspired */}
        <section className="relative overflow-hidden py-24 md:py-36">
          {/* Background effects */}
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/10 via-background to-background" />
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/20 rounded-full blur-[128px]" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent/20 rounded-full blur-[128px]" />

          <div className="container relative px-4">
            <div className="max-w-4xl mx-auto text-center">
              {/* Badge */}
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-border bg-card/50 backdrop-blur-sm text-sm mb-8">
                <Sparkles className="h-4 w-4 text-primary" />
                <span className="text-muted-foreground">Over 50,000 GPUs available globally</span>
              </div>

              {/* Main heading - Kilo Code style with gradient */}
              <h1 className="text-4xl sm:text-5xl md:text-7xl font-bold tracking-tight mb-6 text-balance">
                Move at{" "}
                <span className="bg-gradient-to-r from-primary via-amber-400 to-accent bg-clip-text text-transparent">
                  GPU Speed
                </span>
              </h1>

              <p className="text-lg md:text-xl text-muted-foreground mb-10 max-w-2xl mx-auto text-balance leading-relaxed">
                The all-in-one GPU cloud marketplace. Train ML models, run inference, or deploy AI applications with
                instant access to thousands of GPUs worldwide.
              </p>

              {/* CTA buttons */}
              <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
                <Button
                  size="lg"
                  className="h-12 px-8 text-base font-medium bg-gradient-to-r from-primary to-amber-500 hover:from-primary/90 hover:to-amber-500/90 text-primary-foreground"
                  asChild
                >
                  <Link href="/search">
                    Get Started with TokeIIIa
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Link>
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="h-12 px-8 text-base font-medium border-border hover:bg-secondary bg-transparent"
                  asChild
                >
                  <Link href="/docs">Documentation</Link>
                </Button>
              </div>

              {/* Trust badges */}
              <div className="flex flex-wrap justify-center gap-x-8 gap-y-3 text-sm text-muted-foreground">
                <div className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-primary" />
                  <span>No credit card required</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-accent" />
                  <span>Instant GPU access</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-primary" />
                  <span>Pay as you go</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="py-16 border-y border-border bg-card/30">
          <div className="container px-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
              {gpuStats.map((stat, i) => (
                <div key={stat.label} className="text-center p-4">
                  <div className={`text-3xl md:text-5xl font-bold mb-2 font-mono ${stat.color}`}>{stat.value}</div>
                  <div className="text-sm text-muted-foreground font-medium">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-24">
          <div className="container px-4">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">
                Why choose <span className="text-primary">TokeIIIa</span>?
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                The all-in-one platform for GPU cloud computing with transparent pricing and instant deployment.
              </p>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {features.map((feature) => (
                <div
                  key={feature.title}
                  className={`group p-6 rounded-xl border border-border bg-gradient-to-br ${feature.gradient} hover:border-primary/50 transition-all duration-300`}
                >
                  <div className="h-12 w-12 rounded-lg bg-card border border-border flex items-center justify-center mb-4 group-hover:border-primary/50 transition-colors">
                    <feature.icon className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{feature.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* GPU Types Section */}
        <section className="py-24 bg-card/30 border-y border-border">
          <div className="container px-4">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Popular GPU types</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                From budget-friendly options to the latest data center GPUs, find the perfect hardware for your
                workload.
              </p>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
              {gpuTypes.map((gpu) => (
                <Link
                  key={gpu.name}
                  href={`/search?gpu=${gpu.name}`}
                  className="group p-5 rounded-xl border border-border bg-background hover:border-primary/50 transition-all duration-200"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="h-10 w-10 rounded-lg bg-secondary flex items-center justify-center">
                      <Server className="h-5 w-5 text-muted-foreground group-hover:text-primary transition-colors" />
                    </div>
                    {gpu.tag && (
                      <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${gpu.tagColor}`}>{gpu.tag}</span>
                    )}
                  </div>
                  <h3 className="text-base font-semibold mb-1">{gpu.name}</h3>
                  <div className="flex items-baseline gap-1 mb-2">
                    <span className="text-2xl font-bold text-primary font-mono">{gpu.price}</span>
                    <span className="text-sm text-muted-foreground">{gpu.unit}</span>
                  </div>
                  <p className="text-xs text-muted-foreground font-mono">{gpu.performance}</p>
                </Link>
              ))}
            </div>
            <div className="text-center mt-10">
              <Button variant="outline" className="border-border hover:border-primary/50 bg-transparent" asChild>
                <Link href="/search">
                  View all GPUs
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </section>

        {/* Use Cases Section - Kilo Code style */}
        <section className="py-24">
          <div className="container px-4">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Built for every workload</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Whether you're training models, running inference, or deploying applications.
              </p>
            </div>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="p-6 rounded-xl border border-border bg-gradient-to-br from-primary/5 to-transparent">
                <Cpu className="h-10 w-10 text-primary mb-4" />
                <h3 className="text-xl font-semibold mb-2">ML Training</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  Train large language models and neural networks with access to the latest NVIDIA GPUs at competitive
                  prices.
                </p>
              </div>
              <div className="p-6 rounded-xl border border-border bg-gradient-to-br from-accent/5 to-transparent">
                <Cloud className="h-10 w-10 text-accent mb-4" />
                <h3 className="text-xl font-semibold mb-2">Inference</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  Deploy AI models for production inference with auto-scaling and low-latency responses worldwide.
                </p>
              </div>
              <div className="p-6 rounded-xl border border-border bg-gradient-to-br from-primary/5 to-transparent">
                <Lock className="h-10 w-10 text-primary mb-4" />
                <h3 className="text-xl font-semibold mb-2">Research</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  Accelerate your research with flexible GPU access. No long-term commitments required.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-24 border-t border-border">
          <div className="container px-4">
            <div className="max-w-3xl mx-auto text-center">
              <div className="inline-flex items-center justify-center h-16 w-16 rounded-2xl bg-gradient-to-br from-primary/20 to-accent/20 mb-6">
                <Sparkles className="h-8 w-8 text-primary" />
              </div>
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to get started?</h2>
              <p className="text-lg text-muted-foreground mb-8">
                Create an account and start renting GPUs in minutes. No commitment, pay only for what you use.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button
                  size="lg"
                  className="h-12 px-8 text-base font-medium bg-gradient-to-r from-primary to-amber-500 hover:from-primary/90 hover:to-amber-500/90"
                  asChild
                >
                  <Link href="/auth/sign-up">
                    Create free account
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Link>
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="h-12 px-8 text-base font-medium border-border hover:bg-secondary bg-transparent"
                  asChild
                >
                  <Link href="/pricing">View pricing</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
