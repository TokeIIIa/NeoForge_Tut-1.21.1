import { createClient } from "@/lib/supabase/server"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { GPUSearchClient } from "@/components/gpu-search-client"
import type { GPUMachine } from "@/lib/types"

export default async function SearchPage() {
  const supabase = await createClient()

  const { data: machines } = await supabase
    .from("gpu_machines")
    .select("*")
    .eq("rentable", true)
    .order("dph_base", { ascending: true })

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-1 container px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">GPU Marketplace</h1>
          <p className="text-muted-foreground">
            Browse available GPU instances and find the perfect hardware for your workload
          </p>
        </div>
        <GPUSearchClient initialMachines={(machines as GPUMachine[]) || []} />
      </main>
      <Footer />
    </div>
  )
}
