import { createClient } from "@/lib/supabase/server"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import type { Template } from "@/lib/types"
import { Box, Terminal, ArrowRight } from "lucide-react"

export default async function TemplatesPage() {
  const supabase = await createClient()

  const { data: templates } = await supabase.from("templates").select("*").eq("is_public", true).order("name")

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-1 container px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Templates</h1>
          <p className="text-muted-foreground">
            Pre-configured environments for common ML and AI workloads. Deploy in seconds.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {((templates as Template[]) || []).map((template) => (
            <Card key={template.id} className="hover:border-primary/50 transition-colors">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="p-2 rounded-md bg-primary/10 mb-3">
                    <Box className="h-5 w-5 text-primary" />
                  </div>
                  <Badge variant="outline" className="capitalize">
                    {template.runtype}
                  </Badge>
                </div>
                <CardTitle>{template.name}</CardTitle>
                <CardDescription>{template.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 mb-4">
                  <div className="flex items-center gap-2 text-sm">
                    <Terminal className="h-4 w-4 text-muted-foreground" />
                    <code className="text-xs bg-muted px-2 py-1 rounded truncate">{template.image}</code>
                  </div>
                  <div className="text-sm text-muted-foreground">Disk: {template.disk_space} GB</div>
                </div>
                <Button variant="outline" className="w-full bg-transparent" asChild>
                  <Link href={`/search?template=${template.id}`}>
                    Deploy Template
                    <ArrowRight className="h-4 w-4 ml-2" />
                  </Link>
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </main>
      <Footer />
    </div>
  )
}
