"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { createClient } from "@/lib/supabase/client"
import { toast } from "sonner"
import type { Profile, Transaction } from "@/lib/types"
import { Server, ArrowLeft, CreditCard, Plus, ArrowUpRight, ArrowDownRight } from "lucide-react"
import { useRouter } from "next/navigation"

interface BillingPageProps {
  profile: Profile
  transactions: Transaction[]
}

export function BillingPage({ profile, transactions }: BillingPageProps) {
  const [amount, setAmount] = useState(10)
  const [isLoading, setIsLoading] = useState(false)
  const supabase = createClient()
  const router = useRouter()

  const handleAddCredits = async () => {
    setIsLoading(true)

    try {
      // In a real app, this would integrate with Stripe
      // For demo purposes, we'll just add credits directly
      const newCredits = profile.credits + amount

      const { error: profileError } = await supabase
        .from("profiles")
        .update({ credits: newCredits })
        .eq("id", profile.id)

      if (profileError) throw profileError

      const { error: txError } = await supabase.from("transactions").insert({
        user_id: profile.id,
        type: "credit",
        amount: amount,
        description: `Added $${amount.toFixed(2)} credits`,
      })

      if (txError) throw txError

      toast.success(`Added $${amount.toFixed(2)} to your account!`)
      router.refresh()
    } catch (error) {
      console.error(error)
      toast.error("Failed to add credits. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border/40 bg-background/95 backdrop-blur">
        <div className="container flex h-16 items-center gap-4 px-4">
          <Link href="/" className="flex items-center gap-2">
            <Server className="h-6 w-6 text-primary" />
            <span className="text-xl font-bold">Vast.ai</span>
          </Link>
          <Badge variant="secondary">Billing</Badge>
        </div>
      </header>

      <main className="container px-4 py-8 max-w-4xl">
        <Button variant="ghost" asChild className="mb-6">
          <Link href="/console">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Console
          </Link>
        </Button>

        <h1 className="text-3xl font-bold mb-8">Billing & Credits</h1>

        <div className="grid gap-6">
          {/* Current Balance */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CreditCard className="h-5 w-5" />
                Current Balance
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold text-primary mb-4">${profile.credits.toFixed(2)}</div>
              <p className="text-sm text-muted-foreground">
                Credits are used to pay for GPU instance rentals. Add credits to keep your instances running.
              </p>
            </CardContent>
          </Card>

          {/* Add Credits */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Plus className="h-5 w-5" />
                Add Credits
              </CardTitle>
              <CardDescription>
                Add funds to your account. For demo purposes, credits are added instantly.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex-1">
                  <Label htmlFor="amount">Amount (USD)</Label>
                  <Input
                    id="amount"
                    type="number"
                    min={5}
                    max={1000}
                    value={amount}
                    onChange={(e) => setAmount(Number(e.target.value))}
                  />
                </div>
                <div className="flex items-end">
                  <Button onClick={handleAddCredits} disabled={isLoading || amount < 5}>
                    {isLoading ? "Processing..." : `Add $${amount.toFixed(2)}`}
                  </Button>
                </div>
              </div>
              <div className="flex gap-2 mt-4">
                {[10, 25, 50, 100].map((preset) => (
                  <Button key={preset} variant="outline" size="sm" onClick={() => setAmount(preset)}>
                    ${preset}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Transaction History */}
          <Card>
            <CardHeader>
              <CardTitle>Transaction History</CardTitle>
              <CardDescription>Your recent billing activity</CardDescription>
            </CardHeader>
            <CardContent>
              {transactions.length === 0 ? (
                <p className="text-center py-8 text-muted-foreground">No transactions yet</p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead className="text-right">Amount</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {transactions.map((tx) => (
                      <TableRow key={tx.id}>
                        <TableCell className="text-muted-foreground">
                          {new Date(tx.created_at).toLocaleDateString()}
                        </TableCell>
                        <TableCell>{tx.description}</TableCell>
                        <TableCell>
                          <Badge variant={tx.type === "credit" ? "default" : "secondary"}>
                            {tx.type === "credit" ? (
                              <ArrowDownRight className="h-3 w-3 mr-1" />
                            ) : (
                              <ArrowUpRight className="h-3 w-3 mr-1" />
                            )}
                            {tx.type}
                          </Badge>
                        </TableCell>
                        <TableCell
                          className={`text-right font-mono ${tx.type === "credit" ? "text-green-500" : "text-red-500"}`}
                        >
                          {tx.type === "credit" ? "+" : "-"}${tx.amount.toFixed(2)}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
