"use client"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import type { GPUMachine } from "@/lib/types"
import { Cpu, HardDrive, MapPin, Shield, Zap, MemoryStick, Gauge } from "lucide-react"
import Link from "next/link"

interface GPUCardProps {
  machine: GPUMachine
}

export function GPUCard({ machine }: GPUCardProps) {
  const formatRAM = (mb: number) => {
    if (mb >= 1024) {
      return `${(mb / 1024).toFixed(0)} GB`
    }
    return `${mb} MB`
  }

  return (
    <div className="p-4 rounded-lg border border-border/40 bg-card/50 hover:bg-card transition-colors">
      <div className="flex flex-col lg:flex-row lg:items-center gap-4">
        {/* GPU Info */}
        <div className="flex-1">
          <div className="flex items-start gap-3 mb-3">
            <div className="p-2 rounded-md bg-primary/10">
              <Zap className="h-5 w-5 text-primary" />
            </div>
            <div>
              <div className="flex items-center gap-2 mb-1">
                <h3 className="font-semibold">
                  {machine.gpu_count > 1 && `${machine.gpu_count}x `}
                  {machine.gpu_name}
                </h3>
                {machine.verification === "verified" && (
                  <Badge variant="secondary" className="text-xs">
                    <Shield className="h-3 w-3 mr-1" />
                    Verified
                  </Badge>
                )}
              </div>
              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                <span className="flex items-center gap-1">
                  <MemoryStick className="h-3.5 w-3.5" />
                  {formatRAM(machine.gpu_ram)} VRAM
                </span>
                {machine.dlperf && (
                  <span className="flex items-center gap-1">
                    <Gauge className="h-3.5 w-3.5" />
                    {machine.dlperf.toFixed(1)} DLPerf
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Specs Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
            <div className="flex items-center gap-2 text-muted-foreground">
              <Cpu className="h-4 w-4" />
              <span className="truncate">{machine.cpu_name || "N/A"}</span>
            </div>
            <div className="flex items-center gap-2 text-muted-foreground">
              <MemoryStick className="h-4 w-4" />
              <span>{machine.cpu_ram ? formatRAM(machine.cpu_ram) : "N/A"} RAM</span>
            </div>
            <div className="flex items-center gap-2 text-muted-foreground">
              <HardDrive className="h-4 w-4" />
              <span>{machine.disk_space?.toFixed(0) || "N/A"} GB Disk</span>
            </div>
            <div className="flex items-center gap-2 text-muted-foreground">
              <MapPin className="h-4 w-4" />
              <span className="truncate">{machine.geolocation || "Unknown"}</span>
            </div>
          </div>
        </div>

        {/* Pricing & Action */}
        <div className="flex lg:flex-col items-center lg:items-end gap-4 lg:gap-2 pt-3 lg:pt-0 border-t lg:border-t-0 border-border/40">
          <div className="text-right">
            <div className="text-2xl font-bold text-primary">
              ${machine.dph_base.toFixed(2)}
              <span className="text-sm font-normal text-muted-foreground">/hr</span>
            </div>
            {machine.min_bid && (
              <div className="text-xs text-muted-foreground">Min bid: ${machine.min_bid.toFixed(2)}/hr</div>
            )}
          </div>
          <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2">
            <div
              className="w-2 h-2 rounded-full"
              style={{
                backgroundColor:
                  machine.reliability >= 0.98
                    ? "oklch(0.70 0.18 145)"
                    : machine.reliability >= 0.95
                      ? "oklch(0.75 0.15 60)"
                      : "oklch(0.60 0.20 25)",
              }}
            />
            {(machine.reliability * 100).toFixed(1)}% reliability
          </div>
          <Button asChild>
            <Link href={`/rent/${machine.id}`}>Rent Now</Link>
          </Button>
        </div>
      </div>
    </div>
  )
}
