"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { createClient } from "@/lib/supabase/client"
import { toast } from "sonner"
import type { GPUMachine, Template } from "@/lib/types"
import { Cpu, HardDrive, MapPin, Shield, Zap, MemoryStick, ArrowLeft } from "lucide-react"
import Link from "next/link"

interface RentFormProps {
  machine: GPUMachine
  templates: Template[]
}

export function RentForm({ machine, templates }: RentFormProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [label, setLabel] = useState("")
  const [templateId, setTemplateId] = useState<string>("")
  const [image, setImage] = useState("nvidia/cuda:12.1.1-devel-ubuntu22.04")
  const [runtype, setRuntype] = useState("ssh")
  const [diskSpace, setDiskSpace] = useState(20)
  const [onstart, setOnstart] = useState("")
  const [isBid, setIsBid] = useState(false)
  const [bidPrice, setBidPrice] = useState(machine.min_bid || machine.dph_base * 0.8)
  const router = useRouter()
  const supabase = createClient()

  const selectedTemplate = templates.find((t) => t.id.toString() === templateId)

  const handleTemplateChange = (value: string) => {
    setTemplateId(value)
    const template = templates.find((t) => t.id.toString() === value)
    if (template) {
      setImage(template.image)
      setRuntype(template.runtype)
      setDiskSpace(template.disk_space)
      setOnstart(template.onstart || "")
    }
  }

  const totalPrice = isBid ? bidPrice : machine.dph_base

  const handleRent = async () => {
    setIsLoading(true)

    try {
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        router.push("/auth/login")
        return
      }

      // Check credits
      const { data: profile } = await supabase.from("profiles").select("credits").eq("id", user.id).single()

      if (!profile || profile.credits < totalPrice) {
        toast.error("Insufficient credits. Please add funds to your account.")
        router.push("/console/billing")
        return
      }

      // Create instance
      const { data: instance, error } = await supabase
        .from("instances")
        .insert({
          user_id: user.id,
          machine_id: machine.id,
          label: label || `${machine.gpu_name} Instance`,
          image,
          template_id: selectedTemplate?.id || null,
          template_name: selectedTemplate?.name || null,
          runtype,
          disk_space: diskSpace,
          dph_total: totalPrice,
          is_bid: isBid,
          bid_price: isBid ? bidPrice : null,
          onstart: onstart || null,
          status: "pending",
          cur_state: "creating",
          ssh_host: `ssh${machine.host_id}.vast.ai`,
          ssh_port: 20000 + Math.floor(Math.random() * 10000),
          jupyter_token: runtype.includes("jupyter") ? crypto.randomUUID() : null,
          start_date: new Date().toISOString(),
        })
        .select()
        .single()

      if (error) throw error

      // Create transaction
      await supabase.from("transactions").insert({
        user_id: user.id,
        instance_id: instance.id,
        type: "debit",
        amount: totalPrice,
        description: `Instance rental: ${machine.gpu_name}`,
      })

      // Update credits
      await supabase
        .from("profiles")
        .update({ credits: profile.credits - totalPrice })
        .eq("id", user.id)

      // Simulate instance starting
      setTimeout(async () => {
        await supabase.from("instances").update({ status: "running", cur_state: "running" }).eq("id", instance.id)
      }, 3000)

      toast.success("Instance created successfully!")
      router.push("/console")
    } catch (error) {
      console.error(error)
      toast.error("Failed to create instance. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  const formatRAM = (mb: number) => {
    if (mb >= 1024) {
      return `${(mb / 1024).toFixed(0)} GB`
    }
    return `${mb} MB`
  }

  return (
    <div className="max-w-4xl mx-auto">
      <Button variant="ghost" asChild className="mb-6">
        <Link href="/search">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Search
        </Link>
      </Button>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Machine Details */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="h-5 w-5 text-primary" />
                {machine.gpu_count > 1 && `${machine.gpu_count}x `}
                {machine.gpu_name}
                {machine.verification === "verified" && (
                  <Badge variant="secondary" className="text-xs ml-2">
                    <Shield className="h-3 w-3 mr-1" />
                    Verified
                  </Badge>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="flex items-center gap-2">
                  <MemoryStick className="h-4 w-4 text-muted-foreground" />
                  <span>{formatRAM(machine.gpu_ram)} VRAM</span>
                </div>
                <div className="flex items-center gap-2">
                  <Cpu className="h-4 w-4 text-muted-foreground" />
                  <span>{machine.cpu_name}</span>
                </div>
                <div className="flex items-center gap-2">
                  <MemoryStick className="h-4 w-4 text-muted-foreground" />
                  <span>{machine.cpu_ram ? formatRAM(machine.cpu_ram) : "N/A"} System RAM</span>
                </div>
                <div className="flex items-center gap-2">
                  <HardDrive className="h-4 w-4 text-muted-foreground" />
                  <span>{machine.disk_space?.toFixed(0)} GB Max Disk</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-muted-foreground" />
                  <span>{machine.geolocation}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-muted-foreground">CUDA:</span>
                  <span>{machine.cuda_version || "N/A"}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Configuration Form */}
          <Card>
            <CardHeader>
              <CardTitle>Instance Configuration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="label">Instance Label</Label>
                <Input
                  id="label"
                  placeholder="My ML Training Job"
                  value={label}
                  onChange={(e) => setLabel(e.target.value)}
                />
              </div>

              <div>
                <Label htmlFor="template">Template (Optional)</Label>
                <Select value={templateId} onValueChange={handleTemplateChange}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a template or configure manually" />
                  </SelectTrigger>
                  <SelectContent>
                    {templates.map((template) => (
                      <SelectItem key={template.id} value={template.id.toString()}>
                        {template.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="image">Docker Image</Label>
                <Input
                  id="image"
                  placeholder="nvidia/cuda:12.1.1-devel-ubuntu22.04"
                  value={image}
                  onChange={(e) => setImage(e.target.value)}
                />
              </div>

              <div>
                <Label htmlFor="runtype">Launch Type</Label>
                <Select value={runtype} onValueChange={setRuntype}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ssh">SSH</SelectItem>
                    <SelectItem value="jupyter">Jupyter Notebook</SelectItem>
                    <SelectItem value="jupyter_direct">Jupyter Direct</SelectItem>
                    <SelectItem value="ssh_proxy">SSH Proxy</SelectItem>
                    <SelectItem value="args">Custom Args</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="disk">Disk Space: {diskSpace} GB</Label>
                <Input
                  id="disk"
                  type="range"
                  min={10}
                  max={machine.disk_space || 500}
                  value={diskSpace}
                  onChange={(e) => setDiskSpace(Number(e.target.value))}
                  className="mt-2"
                />
              </div>

              <div>
                <Label htmlFor="onstart">On-Start Script (Optional)</Label>
                <Textarea
                  id="onstart"
                  placeholder="Commands to run when instance starts..."
                  value={onstart}
                  onChange={(e) => setOnstart(e.target.value)}
                  rows={3}
                />
              </div>

              <div className="flex items-center justify-between pt-2">
                <div>
                  <Label htmlFor="bid">Use Interruptible (Bid)</Label>
                  <p className="text-xs text-muted-foreground">Lower cost but may be interrupted</p>
                </div>
                <Switch id="bid" checked={isBid} onCheckedChange={setIsBid} />
              </div>

              {isBid && machine.min_bid && (
                <div>
                  <Label htmlFor="bidPrice">Bid Price ($/hr)</Label>
                  <Input
                    id="bidPrice"
                    type="number"
                    step={0.01}
                    min={machine.min_bid}
                    max={machine.dph_base}
                    value={bidPrice}
                    onChange={(e) => setBidPrice(Number(e.target.value))}
                  />
                  <p className="text-xs text-muted-foreground mt-1">Min: ${machine.min_bid.toFixed(2)}/hr</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Pricing Summary */}
        <div>
          <Card className="sticky top-24">
            <CardHeader>
              <CardTitle>Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">GPU Compute</span>
                  <span>${totalPrice.toFixed(2)}/hr</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Storage ({diskSpace} GB)</span>
                  <span>Included</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Type</span>
                  <span>{isBid ? "Interruptible" : "On-Demand"}</span>
                </div>
              </div>

              <div className="border-t border-border pt-4">
                <div className="flex justify-between font-semibold">
                  <span>Total</span>
                  <span className="text-primary">${totalPrice.toFixed(2)}/hr</span>
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  ~${(totalPrice * 24).toFixed(2)}/day, ~${(totalPrice * 720).toFixed(2)}/month
                </p>
              </div>

              <Button className="w-full" size="lg" onClick={handleRent} disabled={isLoading}>
                {isLoading ? "Creating Instance..." : "Rent Now"}
              </Button>

              <p className="text-xs text-center text-muted-foreground">Billed per second of usage</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
