"use client"

import { useState, useMemo } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { GPUCard } from "@/components/gpu-card"
import type { GPUMachine } from "@/lib/types"
import { Search, SlidersHorizontal, X } from "lucide-react"
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"

interface GPUSearchClientProps {
  initialMachines: GPUMachine[]
}

const GPU_TYPES = [
  "All GPUs",
  "H100 80GB",
  "A100 80GB",
  "A40",
  "A10",
  "RTX 4090",
  "RTX 3090",
  "RTX 3080 Ti",
  "RTX 3080",
  "RTX 3070",
  "RTX 3060 Ti",
  "RTX 3060",
  "RTX 2080 Ti",
  "GTX 1080 Ti",
]

export function GPUSearchClient({ initialMachines }: GPUSearchClientProps) {
  const [search, setSearch] = useState("")
  const [gpuType, setGpuType] = useState("All GPUs")
  const [maxPrice, setMaxPrice] = useState([5])
  const [minReliability, setMinReliability] = useState([90])
  const [verifiedOnly, setVerifiedOnly] = useState(false)
  const [sortBy, setSortBy] = useState<string>("price")

  const filteredMachines = useMemo(() => {
    let result = [...initialMachines]

    // Search filter
    if (search) {
      const searchLower = search.toLowerCase()
      result = result.filter(
        (m) =>
          m.gpu_name.toLowerCase().includes(searchLower) ||
          m.geolocation?.toLowerCase().includes(searchLower) ||
          m.cpu_name?.toLowerCase().includes(searchLower),
      )
    }

    // GPU type filter
    if (gpuType !== "All GPUs") {
      result = result.filter((m) => m.gpu_name === gpuType)
    }

    // Price filter
    result = result.filter((m) => m.dph_base <= maxPrice[0])

    // Reliability filter
    result = result.filter((m) => m.reliability * 100 >= minReliability[0])

    // Verified filter
    if (verifiedOnly) {
      result = result.filter((m) => m.verification === "verified")
    }

    // Sorting
    switch (sortBy) {
      case "price":
        result.sort((a, b) => a.dph_base - b.dph_base)
        break
      case "price-desc":
        result.sort((a, b) => b.dph_base - a.dph_base)
        break
      case "performance":
        result.sort((a, b) => (b.dlperf || 0) - (a.dlperf || 0))
        break
      case "reliability":
        result.sort((a, b) => b.reliability - a.reliability)
        break
      case "gpu-ram":
        result.sort((a, b) => b.gpu_ram - a.gpu_ram)
        break
    }

    return result
  }, [initialMachines, search, gpuType, maxPrice, minReliability, verifiedOnly, sortBy])

  const FilterControls = () => (
    <div className="space-y-6">
      <div>
        <Label className="mb-2 block">GPU Type</Label>
        <Select value={gpuType} onValueChange={setGpuType}>
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {GPU_TYPES.map((type) => (
              <SelectItem key={type} value={type}>
                {type}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div>
        <Label className="mb-2 block">Max Price: ${maxPrice[0].toFixed(2)}/hr</Label>
        <Slider value={maxPrice} onValueChange={setMaxPrice} max={25} min={0.01} step={0.01} className="mt-2" />
      </div>

      <div>
        <Label className="mb-2 block">Min Reliability: {minReliability[0]}%</Label>
        <Slider value={minReliability} onValueChange={setMinReliability} max={100} min={80} step={1} className="mt-2" />
      </div>

      <div className="flex items-center justify-between">
        <Label htmlFor="verified">Verified Hosts Only</Label>
        <Switch id="verified" checked={verifiedOnly} onCheckedChange={setVerifiedOnly} />
      </div>

      <div>
        <Label className="mb-2 block">Sort By</Label>
        <Select value={sortBy} onValueChange={setSortBy}>
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="price">Price: Low to High</SelectItem>
            <SelectItem value="price-desc">Price: High to Low</SelectItem>
            <SelectItem value="performance">Performance</SelectItem>
            <SelectItem value="reliability">Reliability</SelectItem>
            <SelectItem value="gpu-ram">GPU Memory</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Button
        variant="outline"
        className="w-full bg-transparent"
        onClick={() => {
          setSearch("")
          setGpuType("All GPUs")
          setMaxPrice([5])
          setMinReliability([90])
          setVerifiedOnly(false)
          setSortBy("price")
        }}
      >
        <X className="h-4 w-4 mr-2" />
        Reset Filters
      </Button>
    </div>
  )

  return (
    <div className="flex gap-8">
      {/* Desktop Filters */}
      <aside className="hidden lg:block w-64 shrink-0">
        <div className="sticky top-24 p-4 rounded-lg border border-border/40 bg-card/50">
          <h3 className="font-semibold mb-4">Filters</h3>
          <FilterControls />
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1">
        {/* Search Bar */}
        <div className="flex gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by GPU, location, or CPU..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10"
            />
          </div>
          {/* Mobile Filter Button */}
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="outline" className="lg:hidden bg-transparent">
                <SlidersHorizontal className="h-4 w-4" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right">
              <SheetHeader>
                <SheetTitle>Filters</SheetTitle>
              </SheetHeader>
              <div className="mt-6">
                <FilterControls />
              </div>
            </SheetContent>
          </Sheet>
        </div>

        {/* Results Count */}
        <div className="mb-4 text-sm text-muted-foreground">{filteredMachines.length} GPUs available</div>

        {/* GPU Cards */}
        <div className="grid gap-4">
          {filteredMachines.length > 0 ? (
            filteredMachines.map((machine) => <GPUCard key={machine.id} machine={machine} />)
          ) : (
            <div className="text-center py-12 text-muted-foreground">
              No GPUs found matching your criteria. Try adjusting your filters.
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
