"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { createClient } from "@/lib/supabase/client"
import { toast } from "sonner"
import type { Instance, Profile, GPUMachine } from "@/lib/types"
import {
  Server,
  Plus,
  MoreVertical,
  Play,
  Square,
  Trash2,
  Terminal,
  ExternalLink,
  RefreshCw,
  CreditCard,
  Cpu,
  Clock,
  DollarSign,
  LogOut,
  User,
  Key,
  Settings,
} from "lucide-react"
import { useRouter } from "next/navigation"

interface ConsoleDashboardProps {
  profile: Profile
  instances: (Instance & { gpu_machines: GPUMachine })[]
}

export function ConsoleDashboard({ profile, instances: initialInstances }: ConsoleDashboardProps) {
  const [instances, setInstances] = useState(initialInstances)
  const [isLoading, setIsLoading] = useState<number | null>(null)
  const supabase = createClient()
  const router = useRouter()

  const runningInstances = instances.filter((i) => i.status === "running")
  const totalCostPerHour = runningInstances.reduce((acc, i) => acc + i.dph_total, 0)

  const handleAction = async (instanceId: number, action: "start" | "stop" | "destroy" | "reboot") => {
    setIsLoading(instanceId)

    try {
      let newStatus: Instance["status"] = "pending"
      let newState = "pending"

      switch (action) {
        case "start":
          newStatus = "running"
          newState = "running"
          break
        case "stop":
          newStatus = "stopped"
          newState = "stopped"
          break
        case "destroy":
          newStatus = "destroyed"
          newState = "destroyed"
          break
        case "reboot":
          newStatus = "running"
          newState = "rebooting"
          break
      }

      const { error } = await supabase
        .from("instances")
        .update({
          status: newStatus,
          cur_state: newState,
          end_date: action === "destroy" ? new Date().toISOString() : null,
        })
        .eq("id", instanceId)

      if (error) throw error

      if (action === "destroy") {
        setInstances(instances.filter((i) => i.id !== instanceId))
      } else {
        setInstances(instances.map((i) => (i.id === instanceId ? { ...i, status: newStatus, cur_state: newState } : i)))
      }

      toast.success(`Instance ${action === "destroy" ? "destroyed" : action + "ed"} successfully`)
    } catch (error) {
      console.error(error)
      toast.error(`Failed to ${action} instance`)
    } finally {
      setIsLoading(null)
    }
  }

  const handleSignOut = async () => {
    await supabase.auth.signOut()
    router.push("/")
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "running":
        return "bg-green-500"
      case "stopped":
        return "bg-yellow-500"
      case "pending":
        return "bg-blue-500"
      case "error":
        return "bg-red-500"
      default:
        return "bg-gray-500"
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border/40 bg-background/95 backdrop-blur">
        <div className="container flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-4">
            <Link href="/" className="flex items-center gap-2">
              <Server className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold">Vast.ai</span>
            </Link>
            <Badge variant="secondary">Console</Badge>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-sm">
              <span className="text-muted-foreground">Credits: </span>
              <span className="font-mono text-primary">${profile.credits.toFixed(2)}</span>
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <User className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem asChild>
                  <Link href="/console/account">
                    <Settings className="h-4 w-4 mr-2" />
                    Account
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/console/billing">
                    <CreditCard className="h-4 w-4 mr-2" />
                    Billing
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/console/keys">
                    <Key className="h-4 w-4 mr-2" />
                    API Keys
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleSignOut}>
                  <LogOut className="h-4 w-4 mr-2" />
                  Sign Out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container px-4 py-8">
        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="p-2 rounded-md bg-primary/10">
                  <Cpu className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Running Instances</p>
                  <p className="text-2xl font-bold">{runningInstances.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="p-2 rounded-md bg-primary/10">
                  <Server className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Total Instances</p>
                  <p className="text-2xl font-bold">{instances.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="p-2 rounded-md bg-primary/10">
                  <DollarSign className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Cost/Hour</p>
                  <p className="text-2xl font-bold">${totalCostPerHour.toFixed(2)}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="p-2 rounded-md bg-primary/10">
                  <CreditCard className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Credits</p>
                  <p className="text-2xl font-bold">${profile.credits.toFixed(2)}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Instances */}
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">My Instances</h2>
          <Button asChild>
            <Link href="/search">
              <Plus className="h-4 w-4 mr-2" />
              New Instance
            </Link>
          </Button>
        </div>

        {instances.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <Server className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">No Instances Yet</h3>
              <p className="text-muted-foreground mb-4">Create your first GPU instance to get started</p>
              <Button asChild>
                <Link href="/search">Browse GPUs</Link>
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {instances.map((instance) => (
              <Card key={instance.id}>
                <CardContent className="py-4">
                  <div className="flex flex-col lg:flex-row lg:items-center gap-4">
                    {/* Instance Info */}
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <div className={`w-2 h-2 rounded-full ${getStatusColor(instance.status)}`} />
                        <h3 className="font-semibold">{instance.label || `Instance #${instance.id}`}</h3>
                        <Badge variant="outline" className="capitalize">
                          {instance.status}
                        </Badge>
                        {instance.is_bid && <Badge variant="secondary">Interruptible</Badge>}
                      </div>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <Cpu className="h-3.5 w-3.5" />
                          {instance.gpu_machines?.gpu_name || "N/A"}
                        </div>
                        <div className="flex items-center gap-1">
                          <DollarSign className="h-3.5 w-3.5" />${instance.dph_total.toFixed(2)}/hr
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="h-3.5 w-3.5" />
                          {instance.start_date ? new Date(instance.start_date).toLocaleDateString() : "Not started"}
                        </div>
                        <div className="flex items-center gap-1">
                          <Terminal className="h-3.5 w-3.5" />
                          {instance.runtype}
                        </div>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-2">
                      {instance.status === "running" && (
                        <>
                          {instance.runtype.includes("jupyter") && instance.jupyter_token && (
                            <Button variant="outline" size="sm" asChild>
                              <a
                                href={`http://${instance.ssh_host}:${(instance.ssh_port || 0) + 1}/?token=${instance.jupyter_token}`}
                                target="_blank"
                                rel="noopener noreferrer"
                              >
                                <ExternalLink className="h-4 w-4 mr-1" />
                                Jupyter
                              </a>
                            </Button>
                          )}
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              navigator.clipboard.writeText(`ssh -p ${instance.ssh_port} root@${instance.ssh_host}`)
                              toast.success("SSH command copied!")
                            }}
                          >
                            <Terminal className="h-4 w-4 mr-1" />
                            SSH
                          </Button>
                        </>
                      )}

                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" disabled={isLoading === instance.id}>
                            {isLoading === instance.id ? (
                              <RefreshCw className="h-4 w-4 animate-spin" />
                            ) : (
                              <MoreVertical className="h-4 w-4" />
                            )}
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          {instance.status === "stopped" && (
                            <DropdownMenuItem onClick={() => handleAction(instance.id, "start")}>
                              <Play className="h-4 w-4 mr-2" />
                              Start
                            </DropdownMenuItem>
                          )}
                          {instance.status === "running" && (
                            <>
                              <DropdownMenuItem onClick={() => handleAction(instance.id, "stop")}>
                                <Square className="h-4 w-4 mr-2" />
                                Stop
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => handleAction(instance.id, "reboot")}>
                                <RefreshCw className="h-4 w-4 mr-2" />
                                Reboot
                              </DropdownMenuItem>
                            </>
                          )}
                          <DropdownMenuItem
                            onClick={() => handleAction(instance.id, "destroy")}
                            className="text-destructive"
                          >
                            <Trash2 className="h-4 w-4 mr-2" />
                            Destroy
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </main>
    </div>
  )
}
