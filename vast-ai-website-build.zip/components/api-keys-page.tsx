"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { createClient } from "@/lib/supabase/client"
import { toast } from "sonner"
import type { Profile, SSHKey } from "@/lib/types"
import { Server, ArrowLeft, Key, Plus, Copy, Trash2, Eye, EyeOff } from "lucide-react"
import { useRouter } from "next/navigation"

interface APIKeysPageProps {
  profile: Profile
  sshKeys: SSHKey[]
}

export function APIKeysPage({ profile, sshKeys: initialKeys }: APIKeysPageProps) {
  const [sshKeys, setSshKeys] = useState(initialKeys)
  const [showApiKey, setShowApiKey] = useState(false)
  const [newKeyName, setNewKeyName] = useState("")
  const [newKeyPublic, setNewKeyPublic] = useState("")
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const supabase = createClient()
  const router = useRouter()

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text)
    toast.success(`${label} copied to clipboard`)
  }

  const addSSHKey = async () => {
    if (!newKeyName || !newKeyPublic) {
      toast.error("Please fill in all fields")
      return
    }

    setIsLoading(true)

    try {
      const { data, error } = await supabase
        .from("ssh_keys")
        .insert({
          user_id: profile.id,
          name: newKeyName,
          public_key: newKeyPublic,
        })
        .select()
        .single()

      if (error) throw error

      setSshKeys([data, ...sshKeys])
      setNewKeyName("")
      setNewKeyPublic("")
      setIsDialogOpen(false)
      toast.success("SSH key added successfully")
    } catch (error) {
      console.error(error)
      toast.error("Failed to add SSH key")
    } finally {
      setIsLoading(false)
    }
  }

  const deleteSSHKey = async (id: number) => {
    try {
      const { error } = await supabase.from("ssh_keys").delete().eq("id", id)

      if (error) throw error

      setSshKeys(sshKeys.filter((k) => k.id !== id))
      toast.success("SSH key deleted")
    } catch (error) {
      console.error(error)
      toast.error("Failed to delete SSH key")
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border/40 bg-background/95 backdrop-blur">
        <div className="container flex h-16 items-center gap-4 px-4">
          <Link href="/" className="flex items-center gap-2">
            <Server className="h-6 w-6 text-primary" />
            <span className="text-xl font-bold">Vast.ai</span>
          </Link>
          <Badge variant="secondary">API Keys</Badge>
        </div>
      </header>

      <main className="container px-4 py-8 max-w-4xl">
        <Button variant="ghost" asChild className="mb-6">
          <Link href="/console">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Console
          </Link>
        </Button>

        <h1 className="text-3xl font-bold mb-8">API & SSH Keys</h1>

        <div className="grid gap-6">
          {/* API Key */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Key className="h-5 w-5" />
                API Key
              </CardTitle>
              <CardDescription>Use this key to authenticate with the Vast.ai API and CLI</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <div className="flex-1 relative">
                  <Input
                    type={showApiKey ? "text" : "password"}
                    value={profile.api_key}
                    readOnly
                    className="font-mono pr-20"
                  />
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute right-10 top-1/2 -translate-y-1/2"
                    onClick={() => setShowApiKey(!showApiKey)}
                  >
                    {showApiKey ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute right-1 top-1/2 -translate-y-1/2"
                    onClick={() => copyToClipboard(profile.api_key, "API key")}
                  >
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              <p className="text-sm text-muted-foreground mt-2">
                Keep this key secret. Do not share it or commit it to version control.
              </p>
            </CardContent>
          </Card>

          {/* SSH Keys */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>SSH Keys</CardTitle>
                  <CardDescription>Add SSH keys to connect to your instances</CardDescription>
                </div>
                <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                  <DialogTrigger asChild>
                    <Button size="sm">
                      <Plus className="h-4 w-4 mr-2" />
                      Add Key
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add SSH Key</DialogTitle>
                      <DialogDescription>Add your public SSH key to connect to instances</DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 pt-4">
                      <div>
                        <Label htmlFor="keyName">Key Name</Label>
                        <Input
                          id="keyName"
                          placeholder="My MacBook"
                          value={newKeyName}
                          onChange={(e) => setNewKeyName(e.target.value)}
                        />
                      </div>
                      <div>
                        <Label htmlFor="publicKey">Public Key</Label>
                        <Textarea
                          id="publicKey"
                          placeholder="ssh-rsa AAAA..."
                          rows={4}
                          value={newKeyPublic}
                          onChange={(e) => setNewKeyPublic(e.target.value)}
                        />
                      </div>
                      <Button onClick={addSSHKey} disabled={isLoading} className="w-full">
                        {isLoading ? "Adding..." : "Add SSH Key"}
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent>
              {sshKeys.length === 0 ? (
                <p className="text-center py-8 text-muted-foreground">No SSH keys added yet</p>
              ) : (
                <div className="space-y-3">
                  {sshKeys.map((key) => (
                    <div
                      key={key.id}
                      className="flex items-center justify-between p-3 rounded-lg border border-border/40 bg-card/50"
                    >
                      <div>
                        <p className="font-medium">{key.name}</p>
                        <p className="text-xs text-muted-foreground font-mono truncate max-w-md">
                          {key.public_key.substring(0, 50)}...
                        </p>
                        <p className="text-xs text-muted-foreground">
                          Added {new Date(key.created_at).toLocaleDateString()}
                        </p>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => deleteSSHKey(key.id)}
                        className="text-destructive hover:text-destructive"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
