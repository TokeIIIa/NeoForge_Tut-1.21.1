-- Seed public templates
INSERT INTO public.templates (name, description, image, runtype, env_vars, disk_space, is_public) VALUES
('PyTorch 2.0', 'Official PyTorch 2.0 with CUDA 12.1 support', 'pytorch/pytorch:2.0.1-cuda11.7-cudnn8-devel', 'jupyter', '{"JUPYTER_TOKEN": "auto"}', 20, true),
('TensorFlow 2.15', 'TensorFlow with GPU support and Jupyter', 'tensorflow/tensorflow:2.15.0-gpu-jupyter', 'jupyter', '{"JUPYTER_TOKEN": "auto"}', 20, true),
('Stable Diffusion WebUI', 'AUTOMATIC1111 Stable Diffusion WebUI', 'vastai/sd-webui:latest', 'args', '{"COMMANDLINE_ARGS": "--api --listen"}', 50, true),
('ComfyUI', 'ComfyUI for Stable Diffusion workflows', 'vastai/comfyui:latest', 'args', '{}', 50, true),
('vLLM Inference', 'High-throughput LLM inference server', 'vllm/vllm-openai:latest', 'args', '{"MODEL_NAME": "meta-llama/Llama-2-7b-chat-hf"}', 100, true),
('Text Generation WebUI', 'oobabooga text-generation-webui', 'atinoda/text-generation-webui:default', 'args', '{}', 80, true),
('Ubuntu SSH', 'Basic Ubuntu with SSH access', 'nvidia/cuda:12.1.1-devel-ubuntu22.04', 'ssh', '{}', 10, true),
('Jupyter Lab', 'JupyterLab with common ML libraries', 'jupyter/tensorflow-notebook:latest', 'jupyter', '{"JUPYTER_TOKEN": "auto"}', 20, true),
('Ollama', 'Run Ollama LLM server', 'ollama/ollama:latest', 'args', '{}', 50, true),
('Hugging Face Hub', 'Hugging Face Transformers development environment', 'huggingface/transformers-pytorch-gpu:latest', 'jupyter', '{}', 30, true);
