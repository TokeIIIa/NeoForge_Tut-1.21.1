-- Seed GPU machines data (simulated marketplace offers)
INSERT INTO public.gpu_machines (host_id, gpu_name, gpu_count, gpu_ram, gpu_arch, cpu_name, cpu_cores, cpu_ram, disk_space, disk_bw, inet_up, inet_down, geolocation, verification, reliability, dph_base, min_bid, rentable, cuda_version, driver_version, dlperf) VALUES
-- High-end GPUs
(1001, 'RTX 4090', 1, 24576, 'nvidia', 'AMD Ryzen 9 5950X', 16, 65536, 500, 2500, 1000, 1000, 'California, USA', 'verified', 0.9950, 0.45, 0.35, true, '12.1', '535.154', 95.5),
(1002, 'RTX 4090', 2, 49152, 'nvidia', 'Intel i9-13900K', 24, 131072, 1000, 3000, 2000, 2000, 'Texas, USA', 'verified', 0.9920, 0.85, 0.65, true, '12.2', '545.23', 185.2),
(1003, 'RTX 4090', 4, 98304, 'nvidia', 'AMD Threadripper 3970X', 32, 262144, 2000, 3500, 5000, 5000, 'Frankfurt, Germany', 'verified', 0.9980, 1.65, 1.25, true, '12.2', '545.23', 365.8),
(1004, 'A100 80GB', 1, 81920, 'nvidia', 'AMD EPYC 7742', 64, 524288, 1000, 5000, 10000, 10000, 'Virginia, USA', 'verified', 0.9995, 1.85, 1.45, true, '12.0', '525.85', 312.5),
(1005, 'A100 80GB', 8, 655360, 'nvidia', 'AMD EPYC 7763', 128, 1048576, 8000, 7000, 25000, 25000, 'Oregon, USA', 'verified', 0.9998, 14.50, 11.50, true, '12.0', '525.85', 2450.0),
(1006, 'H100 80GB', 1, 81920, 'nvidia', 'Intel Xeon w9-3495X', 56, 524288, 2000, 8000, 25000, 25000, 'California, USA', 'verified', 0.9999, 2.95, 2.35, true, '12.2', '545.23', 485.5),
(1007, 'H100 80GB', 8, 655360, 'nvidia', 'Intel Xeon w9-3495X', 112, 1048576, 16000, 12000, 100000, 100000, 'Tokyo, Japan', 'verified', 0.9999, 22.50, 18.00, true, '12.2', '545.23', 3850.0),

-- Mid-range GPUs
(2001, 'RTX 3090', 1, 24576, 'nvidia', 'AMD Ryzen 7 5800X', 8, 32768, 250, 1500, 500, 500, 'London, UK', 'verified', 0.9850, 0.25, 0.18, true, '11.8', '520.56', 68.5),
(2002, 'RTX 3090', 2, 49152, 'nvidia', 'Intel i7-12700K', 12, 65536, 500, 2000, 1000, 1000, 'Paris, France', 'verified', 0.9880, 0.48, 0.35, true, '11.8', '520.56', 135.2),
(2003, 'RTX 3080 Ti', 1, 12288, 'nvidia', 'AMD Ryzen 5 5600X', 6, 32768, 200, 1200, 400, 400, 'Amsterdam, Netherlands', 'verified', 0.9750, 0.18, 0.12, true, '11.8', '520.56', 52.3),
(2004, 'RTX 3080', 1, 10240, 'nvidia', 'Intel i5-12600K', 10, 32768, 200, 1000, 300, 300, 'Singapore', 'verified', 0.9700, 0.15, 0.10, true, '11.7', '515.65', 45.8),
(2005, 'A10', 1, 24576, 'nvidia', 'AMD EPYC 7443', 24, 131072, 500, 3000, 5000, 5000, 'Sydney, Australia', 'verified', 0.9920, 0.45, 0.35, true, '12.0', '525.85', 125.5),
(2006, 'A40', 1, 49152, 'nvidia', 'Intel Xeon Gold 6330', 28, 262144, 1000, 4000, 10000, 10000, 'Seoul, South Korea', 'verified', 0.9950, 0.65, 0.50, true, '12.0', '525.85', 185.2),

-- Budget GPUs
(3001, 'RTX 3070', 1, 8192, 'nvidia', 'AMD Ryzen 5 3600', 6, 16384, 100, 800, 200, 200, 'Mumbai, India', 'verified', 0.9500, 0.08, 0.05, true, '11.6', '510.73', 32.5),
(3002, 'RTX 3060 Ti', 1, 8192, 'nvidia', 'Intel i5-10400', 6, 16384, 100, 700, 150, 150, 'São Paulo, Brazil', 'verified', 0.9400, 0.06, 0.04, true, '11.6', '510.73', 28.2),
(3003, 'RTX 3060', 1, 12288, 'nvidia', 'AMD Ryzen 3 3300X', 4, 16384, 100, 600, 100, 100, 'Warsaw, Poland', 'unverified', 0.9200, 0.05, 0.03, true, '11.5', '505.75', 22.5),
(3004, 'RTX 2080 Ti', 1, 11264, 'nvidia', 'Intel i7-9700K', 8, 32768, 200, 900, 250, 250, 'Toronto, Canada', 'verified', 0.9350, 0.10, 0.07, true, '11.4', '495.46', 38.5),
(3005, 'GTX 1080 Ti', 1, 11264, 'nvidia', 'AMD Ryzen 5 2600', 6, 16384, 100, 500, 100, 100, 'Mexico City, Mexico', 'unverified', 0.9000, 0.04, 0.02, true, '11.2', '470.82', 18.5),

-- Multi-GPU budget options
(4001, 'RTX 3070', 2, 16384, 'nvidia', 'AMD Ryzen 7 3700X', 8, 32768, 250, 1200, 400, 400, 'Berlin, Germany', 'verified', 0.9600, 0.15, 0.09, true, '11.6', '510.73', 62.5),
(4002, 'RTX 3060', 4, 49152, 'nvidia', 'Intel i9-10900K', 10, 65536, 500, 1500, 500, 500, 'Chicago, USA', 'verified', 0.9550, 0.18, 0.11, true, '11.5', '505.75', 85.2),
(4003, 'RTX 2080 Ti', 4, 45056, 'nvidia', 'AMD Threadripper 2950X', 16, 65536, 500, 1800, 600, 600, 'Stockholm, Sweden', 'verified', 0.9450, 0.35, 0.25, true, '11.4', '495.46', 145.5);
