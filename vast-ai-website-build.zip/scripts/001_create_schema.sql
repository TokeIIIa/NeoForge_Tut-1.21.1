-- Create profiles table for user management
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT,
  full_name TEXT,
  avatar_url TEXT,
  api_key TEXT UNIQUE DEFAULT gen_random_uuid()::text,
  credits DECIMAL(12, 4) DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create GPU machines table (available GPU offers)
CREATE TABLE IF NOT EXISTS public.gpu_machines (
  id SERIAL PRIMARY KEY,
  host_id INTEGER NOT NULL,
  gpu_name TEXT NOT NULL,
  gpu_count INTEGER DEFAULT 1,
  gpu_ram INTEGER NOT NULL, -- in MB
  gpu_arch TEXT DEFAULT 'nvidia',
  cpu_name TEXT,
  cpu_cores INTEGER,
  cpu_ram INTEGER, -- in MB
  disk_space DECIMAL(10, 2), -- in GB
  disk_bw DECIMAL(10, 2), -- disk bandwidth
  inet_up DECIMAL(10, 2), -- upload speed Mbps
  inet_down DECIMAL(10, 2), -- download speed Mbps
  geolocation TEXT,
  verification TEXT DEFAULT 'unverified',
  reliability DECIMAL(5, 4) DEFAULT 0.95,
  dph_base DECIMAL(10, 4) NOT NULL, -- dollars per hour base price
  min_bid DECIMAL(10, 4), -- minimum bid for interruptible
  rentable BOOLEAN DEFAULT TRUE,
  cuda_version TEXT,
  driver_version TEXT,
  dlperf DECIMAL(10, 2), -- deep learning performance score
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create instances table (rented GPU instances)
CREATE TABLE IF NOT EXISTS public.instances (
  id SERIAL PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  machine_id INTEGER NOT NULL REFERENCES public.gpu_machines(id),
  label TEXT,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'running', 'stopped', 'destroyed', 'error')),
  cur_state TEXT DEFAULT 'pending',
  image TEXT NOT NULL DEFAULT 'vastai/base-image:latest',
  template_id INTEGER,
  template_name TEXT,
  runtype TEXT DEFAULT 'ssh' CHECK (runtype IN ('ssh', 'jupyter', 'args', 'ssh_proxy', 'ssh_direct', 'jupyter_proxy', 'jupyter_direct')),
  ssh_host TEXT,
  ssh_port INTEGER,
  jupyter_token TEXT,
  jupyter_url TEXT,
  env_vars JSONB DEFAULT '{}',
  onstart TEXT,
  disk_space DECIMAL(10, 2) DEFAULT 10, -- allocated disk in GB
  dph_total DECIMAL(10, 4) NOT NULL, -- total dollars per hour
  is_bid BOOLEAN DEFAULT FALSE,
  bid_price DECIMAL(10, 4),
  start_date TIMESTAMPTZ,
  end_date TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create billing/transactions table
CREATE TABLE IF NOT EXISTS public.transactions (
  id SERIAL PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  instance_id INTEGER REFERENCES public.instances(id),
  type TEXT NOT NULL CHECK (type IN ('credit', 'debit', 'refund')),
  amount DECIMAL(12, 4) NOT NULL,
  description TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create SSH keys table
CREATE TABLE IF NOT EXISTS public.ssh_keys (
  id SERIAL PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  public_key TEXT NOT NULL,
  fingerprint TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create templates table
CREATE TABLE IF NOT EXISTS public.templates (
  id SERIAL PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  name TEXT NOT NULL,
  description TEXT,
  image TEXT NOT NULL,
  runtype TEXT DEFAULT 'ssh',
  env_vars JSONB DEFAULT '{}',
  onstart TEXT,
  disk_space DECIMAL(10, 2) DEFAULT 10,
  is_public BOOLEAN DEFAULT FALSE,
  hash_id TEXT UNIQUE DEFAULT gen_random_uuid()::text,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS on all tables
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.gpu_machines ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.instances ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ssh_keys ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.templates ENABLE ROW LEVEL SECURITY;

-- Profiles policies
CREATE POLICY "profiles_select_own" ON public.profiles FOR SELECT USING (auth.uid() = id);
CREATE POLICY "profiles_insert_own" ON public.profiles FOR INSERT WITH CHECK (auth.uid() = id);
CREATE POLICY "profiles_update_own" ON public.profiles FOR UPDATE USING (auth.uid() = id);

-- GPU machines are publicly viewable
CREATE POLICY "gpu_machines_select_all" ON public.gpu_machines FOR SELECT TO authenticated USING (true);

-- Instances policies
CREATE POLICY "instances_select_own" ON public.instances FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "instances_insert_own" ON public.instances FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "instances_update_own" ON public.instances FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "instances_delete_own" ON public.instances FOR DELETE USING (auth.uid() = user_id);

-- Transactions policies
CREATE POLICY "transactions_select_own" ON public.transactions FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "transactions_insert_own" ON public.transactions FOR INSERT WITH CHECK (auth.uid() = user_id);

-- SSH keys policies
CREATE POLICY "ssh_keys_select_own" ON public.ssh_keys FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "ssh_keys_insert_own" ON public.ssh_keys FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "ssh_keys_update_own" ON public.ssh_keys FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "ssh_keys_delete_own" ON public.ssh_keys FOR DELETE USING (auth.uid() = user_id);

-- Templates policies (public templates are viewable by all, own templates are editable)
CREATE POLICY "templates_select_public" ON public.templates FOR SELECT USING (is_public = true OR auth.uid() = user_id);
CREATE POLICY "templates_insert_own" ON public.templates FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "templates_update_own" ON public.templates FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "templates_delete_own" ON public.templates FOR DELETE USING (auth.uid() = user_id);

-- Create trigger for auto-creating profile on user signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data ->> 'full_name', NULL)
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_instances_user_id ON public.instances(user_id);
CREATE INDEX IF NOT EXISTS idx_instances_status ON public.instances(status);
CREATE INDEX IF NOT EXISTS idx_gpu_machines_rentable ON public.gpu_machines(rentable);
CREATE INDEX IF NOT EXISTS idx_gpu_machines_gpu_name ON public.gpu_machines(gpu_name);
CREATE INDEX IF NOT EXISTS idx_transactions_user_id ON public.transactions(user_id);
