export interface Profile {
  id: string
  email: string | null
  full_name: string | null
  avatar_url: string | null
  api_key: string
  credits: number
  created_at: string
  updated_at: string
}

export interface GPUMachine {
  id: number
  host_id: number
  gpu_name: string
  gpu_count: number
  gpu_ram: number
  gpu_arch: string
  cpu_name: string | null
  cpu_cores: number | null
  cpu_ram: number | null
  disk_space: number | null
  disk_bw: number | null
  inet_up: number | null
  inet_down: number | null
  geolocation: string | null
  verification: string
  reliability: number
  dph_base: number
  min_bid: number | null
  rentable: boolean
  cuda_version: string | null
  driver_version: string | null
  dlperf: number | null
  created_at: string
  updated_at: string
}

export interface Instance {
  id: number
  user_id: string
  machine_id: number
  label: string | null
  status: "pending" | "running" | "stopped" | "destroyed" | "error"
  cur_state: string
  image: string
  template_id: number | null
  template_name: string | null
  runtype: string
  ssh_host: string | null
  ssh_port: number | null
  jupyter_token: string | null
  jupyter_url: string | null
  env_vars: Record<string, string>
  onstart: string | null
  disk_space: number
  dph_total: number
  is_bid: boolean
  bid_price: number | null
  start_date: string | null
  end_date: string | null
  created_at: string
  updated_at: string
  gpu_machines?: GPUMachine
}

export interface Transaction {
  id: number
  user_id: string
  instance_id: number | null
  type: "credit" | "debit" | "refund"
  amount: number
  description: string | null
  created_at: string
}

export interface SSHKey {
  id: number
  user_id: string
  name: string
  public_key: string
  fingerprint: string | null
  created_at: string
}

export interface Template {
  id: number
  user_id: string | null
  name: string
  description: string | null
  image: string
  runtype: string
  env_vars: Record<string, string>
  onstart: string | null
  disk_space: number
  is_public: boolean
  hash_id: string
  created_at: string
  updated_at: string
}

export interface SearchFilters {
  gpu_name?: string
  min_gpu_ram?: number
  max_price?: number
  min_reliability?: number
  verified_only?: boolean
  sort_by?: "price" | "performance" | "reliability"
  sort_order?: "asc" | "desc"
}
